
<?php
header('content-type:text/html;charset=utf8');
//ajax无刷新分页原理

//利用 mysql limit函数

//通过ajax请求传入页码，通过页码计算出带入limit的一个参数的值 ：如


$dsn="mysql:dbname=ceshi;host=localhost;port=3306";
$username="root";
$password="root";
$mypdo;
try{
    $mypdo=new PDO($dsn, $username, $password);
    $mypdo->query("set names utf8");

}catch (PDOException $pe){

    echo '错误编号：'.$pe->getCode().',错误信息描述：'.$pe->getMessage();
    exit();

}






$page =@$_POST['page'];//从1开始



$allCount=$mypdo->query('select count(*) as counts from t_user')->fetchAll();

$allCount = $allCount[0]['counts'];//总的数据


$limit =2;//每页显示五条数据

$pageNum = ceil(($allCount/$limit));//总的页数



if($page>$pageNum)
{
    $page = $pageNum;
    echo "<script>alert('已经到最后一页了');</script>";
}

$page = $page<1?1:$page;

$ye   = ($page-1)*$limit;//带入limit的第一个参数



$data = $mypdo->query("select * from t_user limit $ye,$limit");

$data = $data->fetchAll();

//执行后返回
$list = '';
foreach($data as $key=>$val)
{
    $list.="<tr>
    <td>$val[id]</td>
    <td>$val[names]</td>
    <td>$val[sex]</td>
    <td>$val[tel]</td>
      </tr>";
}

$list.="<input type='hidden' value='$page' class='pagen'><input type='hidden' value='$pageNum' class='pagem'>";

echo $list;